import React from "react";

function CookiesPopover() {
  return (
    <div>
      <h1 className="text-primary fs-2">404</h1>
      <h3 className="text-dark">Cette page n'exixte pas !</h3>
    </div>
  );
}

export default CookiesPopover;
