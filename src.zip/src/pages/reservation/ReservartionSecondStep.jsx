function ReservartionSecondStep() {
  return (
    <div>
      <h1>Landry</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus fuga
        earum quos, eaque esse reprehenderit modi quibusdam. Illo dolor, odit
        atque fugit error et, neque pariatur dolorem rerum distinctio
        repellendus.
      </p>
    </div>
  );
}

export default ReservartionSecondStep;
