import React, { useState } from "react";
import { Link } from "react-router-dom";

import Navbar from "../../components/Navbar";
import ReservationState from "./components/ReservationState";
import Carousel from "../../pages/contact/components/Carousel";
import Toast from "../../components/Toast";

import slide1 from "../../assets/imgs/contact/slide1.png";
import slide2 from "../../assets/imgs/contact/slide2.png";
import slide3 from "../../assets/imgs/contact/slide3.png";

function ReservationFirstStep() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [mail, setMail] = useState("");
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [phone, setPhone] = useState("");

  const [errors, setErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();

    const errors = {};
    if (!firstName) {
      errors.firstName = "Veuillez entrer votre nom.";
    }
    if (!lastName) {
      errors.lastName = "Veuillez entrer votre prénom.";
    }
    if (!mail) {
      errors.mail = "Veuillez entrer votre nom.";
    }
    if (!country) {
      errors.country = "Veuillez entrer votre pays.";
    }
    if (!city) {
      errors.city = "Veuillez entrer votre ville.";
    }
    if (!phone || isNaN(phone) === true) {
      errors.phone = "Veuillez entrer votre telephone.";
    }

    if (Object.keys(errors).length > 0) {
      setErrors(errors);
      return;
    }
  };

  return (
    <div>
      <Navbar activeLink="reservation" darkTheme="yes" />
      <ReservationState step="step1" />

      <div className="container px-4 px-md-0">
        <div className="row flex-column-reverse flex-lg-row justify-content-between">
          <div className="col-12 col-lg-7">
            <div className="card bg-transparent border-0 shadow-md">
              <div className="card-header border-0 my-3 bg-transparent text-primary">
                <h3 className="fw-bold fs-1">Reservation . . .</h3>
                <p className="text-justify">
                  Toutes les informations demand&eacute;es ici sont neccessaires
                  au bon fonctionnement de votre reservation. Nous vous
                  recommandons donc de fournir des informations validees.
                </p>
              </div>
              <div className="card-body">
                <form
                  onSubmit={handleSubmit}
                  className="needs-validation"
                  noValidate
                >
                  <h4 className="mb-3 fw-medium">Informations personnelles</h4>
                  <div className="row g-3 mt-3">
                    <div className="col-sm-6">
                      <label
                        htmlFor="firstName"
                        className="form-label fw-medium"
                      >
                        Nom
                      </label>
                      <input
                        spellCheck
                        placeholder="Ex: Landry"
                        type="text"
                        id="firstName"
                        className={`form-control text-primary ${
                          errors.firstName ? "is-invalid" : ""
                        }`}
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        maxLength="30"
                        minLength="4"
                        required
                      />
                      {errors.firstName && (
                        <div className="invalid-feedback">
                          {errors.firstName}
                        </div>
                      )}
                    </div>

                    <div className="col-sm-6">
                      <label
                        htmlFor="lastName"
                        className="form-label fw-medium"
                      >
                        Pr&eacute;nom
                      </label>
                      <input
                        spellCheck
                        placeholder="Ex: Joe"
                        type="text"
                        id="lastName"
                        className={`form-control text-primary ${
                          errors.lastName ? "is-invalid" : ""
                        }`}
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        maxLength="30"
                        minLength="4"
                        required
                      />
                      {errors.lastName && (
                        <div className="invalid-feedback">
                          {errors.lastName}
                        </div>
                      )}
                    </div>

                    <div className="col-sm-12">
                      <label htmlFor="mail" className="form-label fw-medium">
                        Email
                      </label>
                      <div className="input-group">
                        <span className="input-group-text">@</span>
                        <input
                          spellCheck
                          placeholder="Ex: landry@gmail.com"
                          type="email"
                          id="mail"
                          className={`form-control text-primary ${
                            errors.mail ? "is-invalid" : ""
                          }`}
                          value={mail}
                          onChange={(e) => setMail(e.target.value)}
                          maxLength="30"
                          minLength="4"
                          required
                        />
                      </div>
                      {errors.mail && (
                        <div className="invalid-feedback">{errors.mail}</div>
                      )}
                    </div>

                    <div className="col-sm-4">
                      <label htmlFor="country" className="form-label fw-medium">
                        Pays
                      </label>
                      <input
                        spellCheck
                        placeholder="Ex: Cameroun"
                        type="text"
                        id="country"
                        className={`form-control text-primary ${
                          errors.country ? "is-invalid" : ""
                        }`}
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        maxLength="30"
                        minLength="4"
                        required
                      />
                      {errors.country && (
                        <div className="invalid-feedback">{errors.country}</div>
                      )}
                    </div>

                    <div className="col-sm-4">
                      <label htmlFor="city" className="form-label fw-medium">
                        Ville
                      </label>
                      <input
                        spellCheck
                        placeholder="Ex: Yaounde"
                        type="text"
                        id="city"
                        className={`form-control text-primary ${
                          errors.city ? "is-invalid" : ""
                        }`}
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        maxLength="30"
                        minLength="4"
                        required
                      />
                      {errors.city && (
                        <div className="invalid-feedback">{errors.city}</div>
                      )}
                    </div>

                    <div className="col-sm-4">
                      <label htmlFor="phone" className="form-label fw-medium">
                        Telephone
                      </label>
                      <input
                        spellCheck
                        placeholder="Ex: Landry"
                        type="text"
                        id="phone"
                        className={`form-control text-primary ${
                          errors.phone ? "is-invalid" : ""
                        } mb-3`}
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        maxLength="30"
                        minLength="9"
                        required
                      />
                      {errors.phone && (
                        <div className="invalid-feedback">{errors.phone}</div>
                      )}
                    </div>

                    <div className="col-sm-5">
                      <label
                        htmlFor="civility"
                        className="form-label fw-medium"
                      >
                        Situation matrimoniale
                      </label>
                      <select className="form-select" id="civility" required>
                        <option value="maried">Mari&eacute;</option>
                        <option value="alone">c&eacute;libataire</option>
                      </select>
                    </div>

                    <hr className="my-5" />

                    <h4 className="mb-3 fw-medium">Genre</h4>
                    <div className="my-3">
                      <div className="form-check">
                        <input
                          id="male"
                          name="gender"
                          type="radio"
                          className="form-check-input"
                          defaultChecked
                          required
                        />
                        <label className="form-check-label" htmlFor="male">
                          Masculin
                        </label>
                      </div>

                      <div className="form-check">
                        <input
                          id="female"
                          name="gender"
                          type="radio"
                          className="form-check-input"
                        />
                        <label className="form-check-label" htmlFor="female">
                          Feminin
                        </label>
                      </div>
                    </div>

                    <hr className="my-5" />

                    <h4 className="mb-1 fw-medium">
                      Conditions d'utilisations
                    </h4>

                    <h6
                      className="form-check-label text-breack mb-5"
                      htmlFor="consentement"
                    >
                      En cliquant sur suivant vous acceptez
                      <Link>la politique de l'hotel</Link> et sa {""}
                      <Link to="">la politique de confidentialit&eacute;</Link>
                    </h6>

                    <button
                      type="submit"
                      className="btn btn-primary fs-5 fw-normal w-100 py-3 my-3"
                    >
                      Suivant
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className="col-12 col-lg-4">
            <Carousel
              imgSlide1={slide1}
              imgSlide2={slide2}
              imgSlide3={slide3}
            />
            <Toast alertMessage="La prochaine &eacute;tape consiste &agrave; nous en dire plus sur votre s&eacute;jour" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default ReservationFirstStep;
