import React, { useState } from "react";

function FormContact() {
  const [firstName, setFirstName] = useState("");
  const [mail, setMail] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();

    const errors = {};
    if (!firstName) {
      errors.firstName = "Veuillez entrer votre prénom.";
    }
    if (!mail) {
      errors.mail = "Veuillez entrer votre nom.";
    }
    if (!message) {
      errors.message = "Veuillez entrer votre message.";
    }

    if (Object.keys(errors).length > 0) {
      setErrors(errors);
      return;
    }
  };

  const handleReset = (e) => {
    setFirstName((e.target.value = ""));
    setMail((e.target.value = ""));
    setMessage((e.target.value = ""));
  };

  return (
    <div className="card border-0 shadow-md">
      <div className="card-header border-0 my-3 bg-transparent d-flex justify-content-between align-items-center text-primary">
        <h3 className="fw-bold fs-2">Contactez nous</h3>
        <span className="bi bi-pencil-square fs-2"></span>
      </div>
      <div className="card-body">
        <form
          onSubmit={handleSubmit}
          onReset={handleReset}
          className="needs-validation"
          noValidate
        >
          <div className="mb-3">
            <label htmlFor="firstName" className="form-label fw-medium">
              Nom
            </label>
            <input
              spellCheck
              placeholder="Ex: Landry"
              type="text"
              id="firstName"
              className={`form-control text-primary bg-light ${
                errors.firstName ? "is-invalid" : ""
              }`}
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              maxLength="30"
              minLength="4"
              required
            />
            {errors.firstName && (
              <div className="invalid-feedback">{errors.firstName}</div>
            )}
          </div>
          <div className="mb-3">
            <label htmlFor="mail" className="form-label fw-medium">
              Email
            </label>
            <input
              spellCheck
              placeholder="Ex: landry@gmail.com"
              type="email"
              id="mail"
              className={`form-control text-primary bg-light ${
                errors.mail ? "is-invalid" : ""
              }`}
              value={mail}
              onChange={(e) => setMail(e.target.value)}
              maxLength="30"
              minLength="4"
              required
            />
            {errors.mail && (
              <div className="invalid-feedback">{errors.mail}</div>
            )}
          </div>
          <div className="mb-3">
            <label htmlFor="message" className="form-label fw-medium">
              Message <span className="badge text-muted">(280 mots max)</span>
            </label>
            <textarea
              cols="30"
              rows="10"
              spellCheck
              placeholder="Votre message ici . . ."
              type="text"
              id="message"
              className={`form-control text-primary bg-light ${
                errors.message ? "is-invalid" : ""
              }`}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              maxLength="280"
              style={{ resize: "none" }}
              required
            ></textarea>
            {errors.message && (
              <div className="invalid-feedback">{errors.message}</div>
            )}
          </div>
          <button
            type="submit"
            className="btn btn-primary fs-5 fw-normal w-100 py-3 my-3"
          >
            Envoyer
          </button>
          <button
            type="reset"
            className="btn btn-danger fs-5 fw-normal w-100 py-3 my-3"
          >
            Effacer
          </button>
        </form>
      </div>
    </div>
  );
}

export default FormContact;
