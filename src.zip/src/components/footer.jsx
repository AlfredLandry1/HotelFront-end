import React from "react";
import { Link } from "react-router-dom";

import "bootstrap-icons/font/bootstrap-icons.css";
import logopaquebot from "../assets/imgs/logopaquebot.svg";
function Footer() {
  return (
    <footer className="bg-primary py-5 px-3 px-md-2 px-lg-0">
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <img
              src={logopaquebot}
              alt="logo"
              width={200}
              className="mb-3 mt-3"
            />
            <p className="mb-4 mt-4 text-light">
              Situé à KRIBI, près de l'école publique de NZIOU
            </p>
            <h2 className="mb-3 mt-3 fw-bold">Nos contacts</h2>
            <ul className="mb-4">
              <li className="mb-2 mt-2 list-unstyled">
                <span className="bi bi-telephone-fill"></span> Tel:xxxxxxxxx
              </li>
              <li className="mb-2 mt-2 list-unstyled">
                <span className="bi bi-envelope-fill"></span> email:xxxxxxxxxx
              </li>
            </ul>
            <h2 className="fw-bold">Suivez-nous</h2>
            <ul className="mb-4">
              <li className="mb-2 mt-2 list-unstyled">
                <span className="bi bi-facebook"></span>
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Facebook
                </Link>
              </li>
              <li className="mb-2 mt-2 list-unstyled">
                <span className="bi bi-instagram"></span>
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Instagram
                </Link>
              </li>
              <li className="mb-2 mt-2 list-unstyled">
                <span className="bi bi-tiktok"></span>
                <Link to="#" className="text-decoration-none text-light fs-5">
                  TikTok
                </Link>
              </li>
            </ul>
            <p className="mb-5 text-light">
              2023 LE PAQUEBOT HOTEL; tous droits réservés
            </p>
          </div>
          <div className="col-md-4">
            <h2 className="fw-bold">Politiques et conditions</h2>
            <ul className="mb-4">
              <li className="mb-2 mt-2 list-unstyled">
                <span className="bi bi-file-earmark-fill"></span>
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Conditions d'utilisation
                </Link>
              </li>
              <li className="mb-2 mt-2 list-unstyled">
                <span className="bi bi-file-lock2-fill"></span>
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Politiques de l'hotel
                </Link>
              </li>
              <li className="mb-2 mt-2 list-unstyled">
                <span className="bi bi-file-lock2-fill"></span>
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Politiques de confidentialité
                </Link>
              </li>
              <li className="mb-2 mt-2 list-unstyled">
                <span className="bi bi-file-earmark-fill"></span>
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Mentions légales
                </Link>
              </li>
            </ul>
          </div>
          <div className="col-md-4">
            <h2 className="fw-bold ">Plan du site</h2>
            <ul className="mb-4">
              <li className="mb-1 mt-1 list-unstyled">
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Accueil
                </Link>
              </li>
              <li className="mb-1 mt-1 list-unstyled">
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Chambres
                </Link>
              </li>
              <li className="mb-1 mt-1 list-unstyled">
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Réserver
                </Link>
              </li>
              <li className="mb-1 mt-1 list-unstyled">
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Services
                </Link>
              </li>
              <li className="mb-1 mt-1 list-unstyled">
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Contactez-nous
                </Link>
              </li>
              <li className="mb-1 mt-1 list-unstyled">
                <Link to="#" className="text-decoration-none text-light fs-5">
                  Localisation
                </Link>
              </li>
              <li className="mb-1 mt-1 list-unstyled">
                <Link to="#" className="text-decoration-none text-light fs-5">
                  S'inscrire/Se connecter
                </Link>
              </li>
            </ul>
            <h2 className="mb-5 fw-bold">Nos partenaires</h2>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
