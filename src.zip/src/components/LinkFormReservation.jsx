import React, { useState } from "react";

function LinkFormReservation() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [commingDate, setCommingDate] = useState("");
  const [goingDate, setGoingDate] = useState("");
  const [errors, setErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();

    const errors = {};
    if (!firstName) {
      errors.firstName = "Veuillez entrer votre prénom.";
    }
    if (!lastName) {
      errors.lastName = "Veuillez entrer votre nom.";
    }
    if (!commingDate) {
      errors.commingDate = "Veuillez entrer une date.";
    }
    if (!goingDate) {
      errors.goingDate = "Veuillez entrer une date.";
    }

    if (Object.keys(errors).length > 0) {
      setErrors(errors);
      return;
    }
  };

  return (
    <div className="col-12 w-100">
      <div className="bg-form rounded-3">
        <div className="bg-glass w-100 rounded-3">
          <div className="card bg-transparent border-0 p-3 rounded-3">
            <div className="card-header d-flex align-items-center bg-transparent border-0">
              <span className="bg-primary fs-2 px-3 py-2 me-3 rounded-circle bi bi-person-plus-fill text-light"></span>
              <h5 className="fw-bold text-light fs-3 text-break">
                Je reserve maintenant
              </h5>
            </div>
            <div className="card-body">
              <form
                onSubmit={handleSubmit}
                action="#"
                className="row gap-3 needs-validation"
                noValidate
              >
                <div className="col-12 col-lg-2">
                  <label
                    htmlFor="firstName"
                    className="form-label fw-normal text-light"
                  >
                    Nom
                  </label>
                  <input
                    placeholder="Ex: Jhon"
                    type="text"
                    id="firstName"
                    className={`form-control text-primary fw-normal ${
                      errors.firstName ? "is-invalid" : ""
                    }`}
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    maxLength="30"
                    minLength="4"
                    required
                  />
                  {errors.firstName && (
                    <div className="invalid-feedback">{errors.firstName}</div>
                  )}
                </div>
                <div className="col-12 col-lg-2">
                  <label
                    htmlFor="lastName"
                    className="form-label fw-normal text-light"
                  >
                    Pr&eacute;nom
                  </label>
                  <input
                    placeholder="Ex: Jhon"
                    type="text"
                    id="lastName"
                    className={`form-control text-primary fw-normal ${
                      errors.lastName ? "is-invalid" : ""
                    }`}
                    value={firstName}
                    onChange={(e) => setLastName(e.target.value)}
                    maxLength="30"
                    minLength="4"
                    required
                  />
                  {errors.firstName && (
                    <div className="invalid-feedback">{errors.firstName}</div>
                  )}
                </div>
                <div className="col-12 col-lg-2">
                  <label
                    htmlFor="commingDate"
                    className="form-label fw-normal text-light"
                  >
                    Date d'arriv&eacute;e
                  </label>
                  <input
                    type="date"
                    className={`form-control text-primary fw-normal ${
                      errors.lastName ? "is-invalid" : ""
                    }`}
                    id="commingDate"
                    value={commingDate}
                    onChange={(e) => setCommingDate(e.target.value)}
                    required
                  />
                  <div className="invalid-feedback">
                    Entrer une date correcte.
                  </div>
                </div>
                <div className="col-12 col-lg-2">
                  <label
                    htmlFor="goingDate"
                    className="form-label fw-normal text-light"
                  >
                    Date de d&eacute;part
                  </label>
                  <input
                    type="date"
                    className={`form-control text-primary fw-normal ${
                      errors.lastName ? "is-invalid" : ""
                    }`}
                    id="goingDate"
                    value={goingDate}
                    onChange={(e) => setGoingDate(e.target.value)}
                    required
                  />
                  <div className="invalid-feedback">
                    Entrer une date correcte.
                  </div>
                </div>
                <div className="col12 col-lg-3">
                  <label htmlFor="" className="opacity-0">
                    Continer
                  </label>
                  <button
                    className="w-100 btn btn-primary btn-lg text-break text-wrap"
                    type="submit"
                  >
                    <span className="bi bi-send-plus-fill pe-3"></span>
                    Continuer
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LinkFormReservation;
